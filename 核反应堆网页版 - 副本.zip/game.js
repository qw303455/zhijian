// 简单的写实风格核反应推原型逻辑
const state = {
  fuel: 100,
  thrust: 0,
  speed: 0,
  running: false,
  auto: false,
  temperature: 20,
  lastAlertKey: '',
};

const el = {
  fuel: document.getElementById('fuel'),
  thrust: document.getElementById('thrust'),
  speed: document.getElementById('speed'),
  inject: document.getElementById('inject'),
  scram: document.getElementById('scram'),
  auto: document.getElementById('auto'),
  core: document.getElementById('core'),
  log: document.getElementById('log'),
  alert: document.getElementById('alert'),
  status: document.getElementById('status'),
  temperature: document.getElementById('temperature'),
};

function log(msg){
  const d = document.createElement('div');
  d.textContent = `[${new Date().toLocaleTimeString()}] ${msg}`;
  el.log.prepend(d);
}

function updateAlerts(){
  if(!el.alert) return;
  const temperature = state.temperature;
  if(temperature >= 170){
    notifyAlert('危险', `温度 ${Math.round(temperature)} ℃，立即停堆！`, 'danger');
  } else if(temperature >= 120){
    notifyAlert('警告', `温度 ${Math.round(temperature)} ℃，接近危险区。`, 'warning');
  } else if(state.fuel > 0 && state.fuel < 20){
    notifyAlert('警告', '燃料低于20%，请补充燃料。', 'warning');
  } else {
    notifyAlert('正常', `温度 ${Math.round(temperature)} ℃，系统稳定。`, 'normal');
  }
}

function notifyAlert(title, message, level){
  if(!el.alert) return;
  const key = `${level}|${message}`;
  if(state.lastAlertKey === key) return;
  state.lastAlertKey = key;
  el.alert.dataset.level = level;
  el.alert.textContent = `${title}：${message}`;
  el.alert.classList.remove('alert-warning','alert-danger','alert-pulse');
  if(level === 'warning'){
    el.alert.classList.add('alert-warning','alert-pulse');
  } else if(level === 'danger'){
    el.alert.classList.add('alert-danger','alert-pulse');
  }
  if(window._sfx){
    if(level === 'warning') window._sfx.pulse(0.04, 520, 0.12);
    if(level === 'danger') window._sfx.pulse(0.08, 220, 0.22);
  }
}

function updateUI(){
  el.fuel.textContent = Math.max(0, Math.floor(state.fuel));
  el.thrust.textContent = state.thrust.toFixed(1);
  el.speed.textContent = state.speed.toFixed(2);
  el.temperature.textContent = `温度: ${Math.round(state.temperature)} ℃`;
  el.status.textContent = state.running ? '运行中' : '待机';
  // core glow based on thrust and temperature
  let glow = el.core.querySelector('.core-glow');
  if(!glow){
    glow = document.createElement('div');
    glow.className='core-glow';
    el.core.appendChild(glow);
  }
  const intensity = Math.min(1, Math.max(0, state.thrust/70 + (state.temperature-20)/160));
  glow.style.background = `radial-gradient(circle at 50% 50%, rgba(255,200,120,${0.2+intensity*0.5}), rgba(220,80,30,${0.03+intensity*0.3}))`;
  glow.style.filter = `blur(${10+intensity*35}px)`;
  updateAlerts();
}

function tick(dt){
  // 自动注入燃料
  if(state.auto && !state.running && state.fuel>0){
    injectFuel(4 * dt);
  }

  // 如果正在运行，燃料消耗产生推力
  if(state.running){
    const burn = 12 * dt; // 每秒消耗基准
    const efficiency = 1 - Math.max(0, Math.min(0.6, state.speed/600));
    const actualBurn = Math.min(state.fuel, burn);
    state.fuel -= actualBurn;
    const produced = actualBurn * (0.9 + 0.5*efficiency);
    // 推力会随生产增加，但有衰减
    state.thrust += produced - (state.thrust * 0.08 * dt);
    // 推力推动速度
    state.speed += state.thrust * 0.025 * dt;
    // 温度上升
    state.temperature += actualBurn * 0.6 * dt + state.thrust * 0.02 * dt;
  } else {
    // 仅速度衰减
    state.speed = Math.max(0, state.speed - state.speed*0.03*dt);
    state.thrust = Math.max(0, state.thrust - state.thrust*0.15*dt);
    state.temperature = Math.max(20, state.temperature - 8 * dt);
  }

  // 温度硬上限
  if(state.temperature >= 190){
    state.temperature = 190;
    if(state.running){
      state.running = false;
      log('过热警告：反应堆自动停堆。');
      notifyAlert('危险', '反应堆过热，已自动停堆', 'danger');
    }
  }

  // 如果燃料耗尽，停止运行
  if(state.fuel <= 0 && state.running){
    state.running = false;
    log('燃料耗尽，反应堆停止。');
    notifyAlert('警告', '燃料耗尽，反应堆停止。', 'warning');
  }

  // 低燃料警告
  if(state.fuel > 0 && state.fuel < 20){
    notifyAlert('警告', '燃料低于20%，请补充燃料。', 'warning');
  }

  updateUI();
}

let last = performance.now();
function loop(){
  const now = performance.now();
  const dt = Math.min(0.1, (now-last)/1000);
  tick(dt);
  last = now;
  // step effects
  if(window._emitter) window._emitter.step(dt);
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);

function injectFuel(amount){
  state.fuel += amount;
  state.temperature = Math.max(20, state.temperature - 4);
  log(`注入燃料：+${Math.round(amount)}。温度稳定。`);
  notifyAlert('信息', '燃料注入成功，反应堆温度稍微下降。', 'normal');
}

el.inject.addEventListener('click', ()=>{
  injectFuel(20);
  if(window._sfx) window._sfx.pulse(0.05,660,0.08);
  if(window._emitter){
    const r = el.core.getBoundingClientRect();
    window._emitter.emit(r.width/2, r.height*0.7, 0.6);
  }
});

el.scram.addEventListener('click', ()=>{
  if(state.running){
    state.running = false;
    log('执行紧急停堆（SCRAM）');
  } else {
    state.running = true;
    log('反应堆启动');
  }
});

el.auto.addEventListener('change', (e)=>{
  state.auto = e.target.checked;
  log(`自动注入 ${state.auto? '开启':'关闭'}`);
});

// 初始化特效
window.addEventListener('load', ()=>{
  try{
    window._emitter = new Effects.ParticleEmitter(el.core);
    window._sfx = new Effects.Sfx();
  }catch(e){console.warn('effects init failed',e)}
});

// 初始UI更新
updateUI();
