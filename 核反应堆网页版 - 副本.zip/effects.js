// 粒子效果与简单音效
class ParticleEmitter{
  constructor(container){
    this.container = container;
    this.canvas = document.createElement('canvas');
    this.canvas.style.position='absolute';
    this.canvas.style.left='0';
    this.canvas.style.top='0';
    this.canvas.width = container.clientWidth;
    this.canvas.height = container.clientHeight;
    container.appendChild(this.canvas);
    this.ctx = this.canvas.getContext('2d');
    this.particles = [];
    window.addEventListener('resize', ()=>this.resize());
  }
  resize(){
    this.canvas.width = this.container.clientWidth;
    this.canvas.height = this.container.clientHeight;
  }
  emit(x,y,intensity){
    const count = Math.min(50, Math.floor(5 + intensity*30));
    for(let i=0;i<count;i++){
      this.particles.push({
        x:x + (Math.random()-0.5)*40,
        y:y + (Math.random()-0.5)*40,
        vx:(Math.random()-0.5)*2*intensity,
        vy:-Math.random()*2*intensity - 0.5,
        life:0, ttl:0.5 + Math.random()*0.8,
        size:2+Math.random()*3
      });
    }
  }
  step(dt){
    const ctx = this.ctx;
    ctx.clearRect(0,0,this.canvas.width,this.canvas.height);
    for(let i=this.particles.length-1;i>=0;i--){
      const p = this.particles[i];
      p.life += dt;
      if(p.life>p.ttl){this.particles.splice(i,1); continue}
      p.vy += 1.5*dt; // gravity-ish
      p.x += p.vx*60*dt; p.y += p.vy*60*dt;
      const a = 1 - p.life/p.ttl;
      ctx.fillStyle = `rgba(255,200,120,${0.6*a})`;
      ctx.beginPath(); ctx.arc(p.x,p.y,p.size*a,0,Math.PI*2); ctx.fill();
    }
  }
}

// 简单音效（使用WebAudio API）
class Sfx{
  constructor(){
    try{this.ctx = new (window.AudioContext || window.webkitAudioContext)()}catch(e){this.ctx=null}
  }
  pulse(vol=0.05,freq=440,dur=0.12){
    if(!this.ctx) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type='sine'; o.frequency.value = freq;
    g.gain.value = vol;
    o.connect(g); g.connect(this.ctx.destination);
    o.start();
    g.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + dur);
    o.stop(this.ctx.currentTime + dur + 0.02);
  }
}

window.Effects = {ParticleEmitter, Sfx};
