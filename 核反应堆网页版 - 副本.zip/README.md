# 核反应推（Web 原型）

这是一个简洁的写实风格网页原型，演示“核反应推”玩法的基础机制：燃料注入 -> 反应堆产生推力 -> 推力驱动速度。

运行方法：

1. 使用 Node 运行程序：

```bash
cd workspace/nuclear-push
node server.js
```

2. 或使用 `npm` 启动：

```bash
cd workspace/nuclear-push
npm start
```

然后打开 `http://localhost:3000`。

如果想继续使用 Python ：

```bash
python -m http.server 8000
```
