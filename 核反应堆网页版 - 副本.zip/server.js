const http = require('http');
const fs = require('fs');
const path = require('path');
const port = process.env.PORT || 3000;
const root = __dirname;
const mimeTypes = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'application/javascript',
};
http.createServer((req, res) => {
  const safePath = path.normalize(path.join(root, req.url === '/' ? '/index.html' : req.url));
  if (!safePath.startsWith(root)) return res.writeHead(403).end('Forbidden');
  fs.readFile(safePath, (err, data) => {
    if (err) {
      res.writeHead(404).end('Not Found');
      return;
    }
    const ext = path.extname(safePath);
    res.writeHead(200, {'Content-Type': mimeTypes[ext] || 'application/octet-stream'});
    res.end(data);
  });
}).listen(port, () => console.log(`核反应推已启动: http://localhost:${port}`));
